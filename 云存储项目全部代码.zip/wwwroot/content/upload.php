<?php
    session_start();
    $user= $_SESSION['username'];
    $type=$_POST['type'];
    $servername="localhost";
    $username="root";
    $password="123456";
    $database="file";
    $conn=new mysqli($servername,$username,$password,$database);
    define('ROOT',dirname(__FILE__).'\\');
    $stored_path = ROOT.'upload\\'.basename($_FILES['file']['name']);
    $fn=basename($_FILES['file']['name']);
    move_uploaded_file($_FILES["file"]["tmp_name"],$stored_path);
    $fnn="/content/upload/".$fn;
    if($type=="s")
    {
        $sql="insert into file values('$user','$fn','$fnn',now(),'0');";
    }
    else if($type=="g")
    {
        $sql="insert into file values('g','$fn','$fnn',now(),'1');";
    }
    if ($conn->query($sql) === TRUE) {
        echo "新记录插入成功";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    echo "<script>alert('文件上传成功！');history.go(-1);</script>";
?> 