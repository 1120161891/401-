<?php  
    $user = $_POST["form-username"];  
    $psw = $_POST["form-password"];  
    $servername="localhost";
    $username="root";
    $password="123456";
    $dbname="user";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("连接失败: " . $conn->connect_error);
    } 
    $sql = "select username,password from user where username = '$user' and password = '$psw'";  
    $result = mysqli_query($conn,$sql);  
    if($result->num_rows<=0)
    {
        echo "<script>alert('用户名或密码不正确！');history.go(-1);</script>";
    }
    else 
    {
        session_start();
        $_SESSION['username']=$user;
        echo "<script>alert('登陆成功！'); location.assign(\"content/index.php\");</script>"; 
    }
?>