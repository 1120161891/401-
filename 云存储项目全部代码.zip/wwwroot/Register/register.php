<?php  
    $user = $_POST["form-username"];  
    $psw = $_POST["form-password"];  
    $psw2 = $_POST["form-password2"];  
    if($psw!=$psw2)
    {
        echo "<script>alert('两次输入密码不一致！');history.go(-1);</script>";
    }
    $servername="localhost";
    $username="root";
    $password="123456";
    $dbname="user";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("连接失败: " . $conn->connect_error);
    } 
    $sql = "select * from user where username = '$user'";  
    $result = mysqli_query($conn,$sql);  
    if($result->num_rows>0)
    {
        echo "<script>alert('用户名已存在！');history.go(-1);</script>";
    }
    else 
    {
        $sql="insert into user values('$user','$psw')";
        $result = mysqli_query($conn,$sql);
        echo "<script>alert('注册成功！'); location.assign(\"../login.html\");</script>"; 
    }
?>